#define TUNE_PROGRAM_BUILD 1
#include "..\..\mpn\generic\mulhigh_n.c"
